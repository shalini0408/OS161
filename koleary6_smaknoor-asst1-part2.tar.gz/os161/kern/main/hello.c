#include <types.h>
#include <lib.h>

void hello(){
	kprintf("Hello World\n"); 
}
