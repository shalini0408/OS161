#ifndef _VERSION_H_
#define _VERSION_H_

/*
 * Leave this alone, so we can tell what version of the OS/161 base
 * code we gave you.
 */
#define BASE_VERSION    "1.11gmu"

/*
 * Change this as you see fit in the course of hacking the system.
 */
#define GROUP_VERSION   "0"


#endif /* _VERSION_H_ */
